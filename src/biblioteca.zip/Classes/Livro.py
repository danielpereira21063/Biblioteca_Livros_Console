class Livro:
    def __init__(self, id_livro, titulo, autor, ano_publicacao, copias):
        self.id_livro = id_livro
        self.titulo = titulo
        self.autor = autor
        self.ano_publicacao = ano_publicacao
        self.copias = copias
